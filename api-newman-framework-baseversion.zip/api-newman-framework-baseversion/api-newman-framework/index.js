
const newman = require('newman');
var params = process.argv;

const fs = require('fs')
const fsPromise = require('fs').promises;


async function* Getcollection(path) {
    const dir = await fsPromise.readdir(path, { withFileTypes: fs.Dirent })
    let collections = []
    let temppath = ""
    let collection = {}
    for  (const dirent of dir) {
       
        if (dirent.isDirectory()) {
         yield *   Getcollection(path + dirent.name + '/')
        } else {

                if (dirent.name.includes("environment")) {
                    collection.env = path + dirent.name
                } else {
                    collection.collection = path + dirent.name
                }
                temppath = path
            if ((collection.env!=undefined)  && (collection.collection!=undefined)  )
            {
                yield  collection
            }
        }
    }
}

(async()=>{
    var i= 0
    for await (let item of Getcollection('./APICollections/')){
     
        newman.run({
            collection: require(item.collection),
            ignoreRedirects: true,
            reporters: ['cli','htmlextra','junit'],
            environment:require(item.env),
            reporter :  {htmlextra: {
                export: './Reports/Reports'+i+'.html'
            },
            junit : { export : './Reports/junit/xmlResults'+i+'.xml' } 
        }
        }, function (err) {
            if (err) { throw err; }
            console.log('collection run complete!');
        }).on('test',function(err,args){
        
            console.log("Test in "+args.item.name +" executed")
        });
        i++
}})()



