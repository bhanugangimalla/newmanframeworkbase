#!/usr/bin/env bash
set -xe
nodeinstalled=$(which node)||true

if [[ -z "${nodeinstalled}" ]]
then
	sudo apt install curl -y 
	curl -sL https://deb.nodesource.com/setup_11.x | sudo -E bash - 
	sudo apt-get install -y nodejs
	sudo apt-get install build-essential -y
	sudo chmod -R 0755 .
	sudo rm -rf .npm
	sudo rm -rf node_modules
	sudo add-apt-repository ppa:openjdk-r/ppa
    sudo apt-get update
    sudo apt-get -f install
    sudo apt-get install openjdk-8-jdk
	wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
sudo dpkg -i google-chrome-stable_current_amd64.deb
	
fi
